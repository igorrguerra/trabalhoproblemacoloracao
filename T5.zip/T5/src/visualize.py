"""
visualize.py — Gera visualização SVG do grafo do Brasil colorido pelo DSatur.

Saída: arquivo SVG que pode ser aberto em qualquer navegador.
Não usa bibliotecas externas — SVG é construído como texto puro.
"""

from graph import Graph

# ----------------------------------------------------------------------
# Coordenadas de visualização (baseadas em lat/lon, com pequenos ajustes
# no cluster do Nordeste para evitar sobreposição de rótulos)
# ----------------------------------------------------------------------
STATE_COORDS = {
    0:  (-9.0, -70.8),   # AC
    1:  (-9.2, -35.8),   # AL  (ajustado)
    2:  (-4.0, -64.0),   # AM
    3:  (1.5, -51.8),    # AP
    4:  (-12.5, -41.5),  # BA
    5:  (-5.0, -39.6),   # CE
    6:  (-15.5, -46.8),  # DF  (ajustado para separar de GO)
    7:  (-19.2, -40.3),  # ES
    8:  (-16.2, -49.8),  # GO  (ajustado)
    9:  (-5.0, -45.5),   # MA
    10: (-18.5, -44.5),  # MG
    11: (-20.5, -54.5),  # MS
    12: (-13.0, -55.9),  # MT
    13: (-4.0, -53.0),   # PA
    14: (-7.1, -35.5),   # PB  (ajustado)
    15: (-8.7, -37.5),   # PE  (ajustado)
    16: (-7.7, -42.7),   # PI
    17: (-24.5, -51.5),  # PR
    18: (-22.0, -42.5),  # RJ
    19: (-5.3, -34.5),   # RN  (ajustado)
    20: (-10.9, -62.8),  # RO
    21: (2.0, -61.8),    # RR
    22: (-30.0, -53.5),  # RS
    23: (-27.0, -50.0),  # SC
    24: (-11.3, -36.5),  # SE  (ajustado)
    25: (-22.2, -48.6),  # SP
    26: (-10.2, -48.3),  # TO
}

# Paleta de cores (hex) — correspondente aos rótulos usados no programa
PALETTE = [
    "#E74C3C",  # 1 Vermelho
    "#3498DB",  # 2 Azul
    "#2ECC71",  # 3 Verde
    "#F1C40F",  # 4 Amarelo
    "#E67E22",  # 5 Laranja
    "#9B59B6",  # 6 Roxo
    "#E91E63",  # 7 Rosa
]

COLOR_NAMES = ["Vermelho", "Azul", "Verde", "Amarelo", "Laranja", "Roxo", "Rosa"]


def _to_svg_coords(lat: float, lon: float) -> tuple[float, float]:
    """Converte coordenadas geográficas (lat, lon) em coordenadas SVG (x, y)."""
    x = (lon + 75) * 18 + 50
    y = (5 - lat) * 16 + 60
    return x, y


def draw_graph_svg(
    graph: Graph,
    colors: list[int],
    state_names: list[str],
    filename: str = "grafo_brasil.svg",
) -> None:
    """Gera um arquivo SVG com a visualização do grafo colorido pelo DSatur."""
    coords = {v: _to_svg_coords(*STATE_COORDS[v]) for v in range(graph.V())}

    width, height = 840, 780
    total_colors = max(colors) + 1

    parts: list[str] = []
    parts.append(
        f'<svg xmlns="http://www.w3.org/2000/svg" '
        f'width="{width}" height="{height}" viewBox="0 0 {width} {height}">'
    )

    # Fundo
    parts.append(f'<rect width="{width}" height="{height}" fill="#F8F9FA"/>')

    # Título
    parts.append(
        '<text x="420" y="32" text-anchor="middle" '
        'font-family="Arial, sans-serif" font-size="20" font-weight="bold" '
        'fill="#2C3E50">Mapa do Brasil como Grafo — Coloração DSatur</text>'
    )

    # Arestas (desenhadas primeiro, para ficarem atrás dos vértices)
    parts.append('<g id="edges" stroke="#7F8C8D" stroke-width="1.5" opacity="0.55">')
    drawn = set()
    for v in range(graph.V()):
        for w in graph.adj(v):
            key = (min(v, w), max(v, w))
            if key in drawn:
                continue
            drawn.add(key)
            x1, y1 = coords[v]
            x2, y2 = coords[w]
            parts.append(
                f'<line x1="{x1:.1f}" y1="{y1:.1f}" '
                f'x2="{x2:.1f}" y2="{y2:.1f}"/>'
            )
    parts.append('</g>')

    # Vértices com rótulos
    parts.append('<g id="nodes">')
    for v in range(graph.V()):
        x, y = coords[v]
        color = PALETTE[colors[v] % len(PALETTE)]
        parts.append(
            f'<circle cx="{x:.1f}" cy="{y:.1f}" r="17" '
            f'fill="{color}" stroke="#2C3E50" stroke-width="2"/>'
        )
        parts.append(
            f'<text x="{x:.1f}" y="{y + 4:.1f}" text-anchor="middle" '
            f'font-family="Arial, sans-serif" font-size="11" font-weight="bold" '
            f'fill="white">{state_names[v]}</text>'
        )
    parts.append('</g>')

    # Separador horizontal entre o grafo e a legenda
    parts.append(
        f'<line x1="30" y1="{height - 110}" x2="{width - 30}" y2="{height - 110}" '
        f'stroke="#BDC3C7" stroke-width="1"/>'
    )

    # Legenda de cores
    legend_y = height - 80
    parts.append(
        f'<text x="50" y="{legend_y}" font-family="Arial, sans-serif" '
        'font-size="15" font-weight="bold" fill="#2C3E50">Legenda:</text>'
    )
    for i in range(total_colors):
        lx = 155 + i * 170
        ly = legend_y - 5
        parts.append(
            f'<circle cx="{lx + 12}" cy="{ly}" r="11" '
            f'fill="{PALETTE[i]}" stroke="#2C3E50" stroke-width="1.5"/>'
        )
        parts.append(
            f'<text x="{lx + 30}" y="{ly + 5}" font-family="Arial, sans-serif" '
            f'font-size="13" fill="#2C3E50">Cor {i + 1} — {COLOR_NAMES[i]}</text>'
        )

    # Rodapé com estatísticas
    parts.append(
        f'<text x="50" y="{height - 30}" font-family="Arial, sans-serif" '
        f'font-size="13" font-weight="bold" fill="#2C3E50">'
        f'Vértices: {graph.V()}    |    Arestas: {graph.E()}    |    '
        f'Cores utilizadas: {total_colors}</text>'
    )

    parts.append('</svg>')

    with open(filename, "w", encoding="utf-8") as f:
        f.write("\n".join(parts))
