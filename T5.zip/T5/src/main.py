"""
main.py — Ponto de entrada do Trabalho Prático 5 (T290).

Uso:
    python main.py <caminho_para_brasil.txt>

Exemplo:
    python main.py dados/brasil.txt
"""

import sys
import os

# Permite importar graph e dsatur independentemente do diretório de execução
sys.path.insert(0, os.path.dirname(__file__))

from graph import Graph
from dsatur import dsatur, validate_coloring
from visualize import draw_graph_svg

# Mapeamento obrigatório: índice → sigla (ordem alfabética)
STATE_NAMES = [
    "AC", "AL", "AM", "AP", "BA", "CE", "DF",
    "ES", "GO", "MA", "MG", "MS", "MT", "PA",
    "PB", "PE", "PI", "PR", "RJ", "RN", "RO",
    "RR", "RS", "SC", "SE", "SP", "TO",
]

# Cores nomeadas para exibição (apenas estética)
COLOR_LABELS = ["Vermelho", "Azul", "Verde", "Amarelo", "Laranja", "Roxo", "Rosa"]


def color_label(c: int) -> str:
    if c < len(COLOR_LABELS):
        return f"{c + 1} ({COLOR_LABELS[c]})"
    return str(c + 1)


def main() -> None:
    if len(sys.argv) < 2:
        print("Uso: python main.py <arquivo>")
        print("Exemplo: python main.py dados/brasil.txt")
        sys.exit(1)

    filepath = sys.argv[1]

    # ------------------------------------------------------------------
    # 1. Construção do grafo
    # ------------------------------------------------------------------
    try:
        graph = Graph.from_file(filepath)
    except FileNotFoundError:
        print(f"Arquivo não encontrado: {filepath}")
        sys.exit(1)

    print("=" * 60)
    print("  COLORAÇÃO DO MAPA DO BRASIL — DSatur")
    print("=" * 60)
    print(f"\nArquivo: {filepath}")
    print(f"Vértices: {graph.V()}  |  Arestas: {graph.E()}")

    # ------------------------------------------------------------------
    # 2. Lista de adjacência
    # ------------------------------------------------------------------
    print("\n" + "─" * 60)
    print("LISTA DE ADJACÊNCIA")
    print("─" * 60)
    for v in range(graph.V()):
        vizinhos = ", ".join(STATE_NAMES[w] for w in sorted(graph.adj(v)))
        grau = graph.degree(v)
        print(f"  {STATE_NAMES[v]:>2} ({v:2d})  grau={grau:2d}  →  {vizinhos}")

    # ------------------------------------------------------------------
    # 3. Execução do DSatur
    # ------------------------------------------------------------------
    print("\n" + "─" * 60)
    print("EXECUÇÃO DO DSatur")
    print("─" * 60)

    colors, order = dsatur(graph)

    print(f"\n{'Passo':>5}  {'Estado':>6}  {'Cor':<20}  DS(v)  grau")
    print("  " + "-" * 48)

    # Recalcula DS e grau no momento da coloração para exibição
    temp_colors = [-1] * graph.V()
    for step, v in enumerate(order):
        ds = len({temp_colors[w] for w in graph.adj(v) if temp_colors[w] != -1})
        grau = graph.degree(v)
        temp_colors[v] = colors[v]
        print(
            f"  {step + 1:>3}.  {STATE_NAMES[v]:>6}  "
            f"cor {color_label(colors[v]):<16}  {ds:>4}  {grau:>4}"
        )

    # ------------------------------------------------------------------
    # 4. Resultado final
    # ------------------------------------------------------------------
    total_colors = max(colors) + 1

    print("\n" + "─" * 60)
    print("COR FINAL DE CADA ESTADO")
    print("─" * 60)
    for v in range(graph.V()):
        print(f"  {STATE_NAMES[v]:>2}: cor {color_label(colors[v])}")

    print("\n" + "─" * 60)
    print(f"  Total de cores utilizadas: {total_colors}")
    print("─" * 60)

    # ------------------------------------------------------------------
    # 5. Validação
    # ------------------------------------------------------------------
    conflicts = validate_coloring(graph, colors)
    print("\n" + "─" * 60)
    print("VALIDAÇÃO DA COLORAÇÃO")
    print("─" * 60)
    if not conflicts:
        print("  ✓ Coloração VÁLIDA — nenhum par de estados adjacentes")
        print("    compartilha a mesma cor.")
    else:
        print("  ✗ Coloração INVÁLIDA — conflitos encontrados:")
        for v, w in conflicts:
            print(f"    {STATE_NAMES[v]} — {STATE_NAMES[w]} (cor {colors[v] + 1})")

    print("=" * 60)

    # ------------------------------------------------------------------
    # 6. Visualização gráfica (SVG)
    # ------------------------------------------------------------------
    svg_file = "grafo_brasil.svg"
    draw_graph_svg(graph, colors, STATE_NAMES, svg_file)
    print(f"\n🗺️  Visualização do grafo salva em: {os.path.abspath(svg_file)}")
    print("    Abra esse arquivo em qualquer navegador para ver o grafo colorido.")


if __name__ == "__main__":
    main()
