"""
graph.py — Grafo não direcionado no padrão algs4.
"""


class Graph:
    """Grafo não direcionado representado por lista de adjacência."""

    def __init__(self, v: int):
        if v < 0:
            raise ValueError("Número de vértices deve ser não-negativo.")
        self._v = v
        self._e = 0
        self._adj = [[] for _ in range(v)]

    # ------------------------------------------------------------------
    # Construção a partir de arquivo no padrão algs4
    # ------------------------------------------------------------------
    @staticmethod
    def from_file(filename: str) -> "Graph":
        """Lê um grafo de um arquivo no padrão algs4."""
        with open(filename) as f:
            v = int(f.readline().strip())
            g = Graph(v)
            e = int(f.readline().strip())
            for _ in range(e):
                line = f.readline().strip()
                if not line:
                    continue
                a, b = map(int, line.split())
                g.add_edge(a, b)
        return g

    # ------------------------------------------------------------------
    # Operações básicas
    # ------------------------------------------------------------------
    def add_edge(self, v: int, w: int) -> None:
        """Adiciona a aresta não direcionada v–w."""
        self._validate(v)
        self._validate(w)
        self._adj[v].append(w)
        self._adj[w].append(v)
        self._e += 1

    def adj(self, v: int) -> list:
        """Retorna os vizinhos de v."""
        self._validate(v)
        return self._adj[v]

    def V(self) -> int:
        """Número de vértices."""
        return self._v

    def E(self) -> int:
        """Número de arestas."""
        return self._e

    def degree(self, v: int) -> int:
        """Grau do vértice v."""
        self._validate(v)
        return len(self._adj[v])

    # ------------------------------------------------------------------
    # Utilidades
    # ------------------------------------------------------------------
    def _validate(self, v: int) -> None:
        if not (0 <= v < self._v):
            raise IndexError(f"Vértice {v} fora do intervalo [0, {self._v - 1}].")

    def __str__(self) -> str:
        lines = [f"Grafo: {self._v} vértices, {self._e} arestas"]
        for v in range(self._v):
            adj_str = " → ".join(map(str, self._adj[v]))
            lines.append(f"  {v:2d}: {adj_str}")
        return "\n".join(lines)
