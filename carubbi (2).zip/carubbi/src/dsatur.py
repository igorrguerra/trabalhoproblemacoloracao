"""
dsatur.py — Algoritmo DSatur para coloração de vértices.

O DSatur (Degree of Saturation) é uma heurística gulosa que, a cada passo,
escolhe o vértice não colorido com maior grau de saturação DS(v), definido
como o número de cores distintas já presentes em sua vizinhança.
Empates são desfeitos pelo maior grau estrutural; persistindo o empate,
pelo menor índice (escolha arbitrária reprodutível).
"""

from graph import Graph


def dsatur(graph: Graph) -> tuple[list[int], list[int]]:
    """
    Aplica o algoritmo DSatur ao grafo e devolve:
        colors : lista onde colors[v] é a cor atribuída ao vértice v (base 0).
        order  : ordem em que os vértices foram coloridos.

    Parâmetros
    ----------
    graph : Graph — grafo não direcionado (algs4).

    Retorno
    -------
    (colors, order)
    """
    n = graph.V()
    colors = [-1] * n          # -1 = não colorido
    order: list[int] = []

    # Passo 1 — colorir o vértice de maior grau com a cor 0
    start = max(range(n), key=lambda v: (graph.degree(v), -v))
    colors[start] = 0
    order.append(start)

    remaining = set(range(n)) - {start}

    while remaining:
        # Calcula DS(v) para cada vértice restante
        def saturation(v: int) -> int:
            return len({colors[w] for w in graph.adj(v) if colors[w] != -1})

        # Escolhe o vértice com maior DS; empate → maior grau; empate → menor índice
        v_next = max(
            remaining,
            key=lambda v: (saturation(v), graph.degree(v), -v)
        )

        # Menor cor viável para v_next
        neighbor_colors = {colors[w] for w in graph.adj(v_next) if colors[w] != -1}
        c = 0
        while c in neighbor_colors:
            c += 1

        colors[v_next] = c
        order.append(v_next)
        remaining.remove(v_next)

    return colors, order


def validate_coloring(graph: Graph, colors: list[int]) -> list[tuple[int, int]]:
    """
    Verifica se a coloração é válida (nenhuma aresta monocromática).
    Retorna lista de conflitos (v, w); lista vazia = coloração válida.
    """
    conflicts = []
    for v in range(graph.V()):
        for w in graph.adj(v):
            if w > v and colors[v] == colors[w]:
                conflicts.append((v, w))
    return conflicts
